/*
 * Copyright 2006 Sun Microsystems, Inc.  All rights reserved.
 * You may not modify, use, reproduce, or distribute this
 * software except in compliance with the terms of the License at:
 *
 *   http://developer.sun.com/berkeley_license.html
 *
 * $Id: Starter.java,v 1.3 2006/04/27 02:16:39 mattbohm Exp $
 */

package com.sun.j2ee.blueprints.ui.progressbar;

import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;

/**
 * Interface implemented by classes which can start a long-running task.
 *
 * @author Matthew Bohm
 */
public interface Starter {
    /** This method is called asynchronously from client scripting.
     * It starts a long-running task.
     *
     */
    public void startTask(FacesContext context);

}
