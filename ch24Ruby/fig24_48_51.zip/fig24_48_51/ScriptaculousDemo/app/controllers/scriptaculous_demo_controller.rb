# Fig. 24.48: app/controllers/scriptaculous_demo_controller.rb
# Script.aculo.us Demo controller
class ScriptaculousDemoController < ApplicationController 
  def playEffect
    render :partial => "link"
  end # method playEffect
end # class ScriptaculousDemoController