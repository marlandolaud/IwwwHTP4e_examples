// Fig. 19.7: Scene.xaml.js
// JavaScript code-behind for Movie Viewer

// instantiate instance variables
var host;
var movieViewer;

function canvasLoaded( sender, eventArgs )
{
   var movieViewer = sender; // allow access to controls
   var host = sender.getHost(); // allow access to host plug-in

   // add an event handler for event OnFullScreenChange
   host.content.onFullScreenChange = onFullScreenChange;

   // update layout of application with current dimensions
   updateLayout( host.content.actualWidth, host.content.actualHeight, sender );

   // start the timer
   var timelineTimer = sender.findName( "timelineTimer" );
   timelineTimer.begin();
} // end function canvasLoaded

// timelineTimer event handler
function updateTime( sender )
{
   // create variables to more easily access the Silverlight elements
   var movieMediaElement = sender.findName( "movieMediaElement" );
   var downloadProgress = sender.findName( "downloadProgress" );
   var timeText = sender.findName( "timeText" );
   var timeline = sender.findName( "timeline" );
   var seekHead = sender.findName( "seekHead" );
   var timelineTimer = sender.findName( "timelineTimer" );
   
   // get the hours, minutes and seconds of the video's current position
   var seconds = movieMediaElement.position.Seconds;
   var hours = convertToHHMMSS( seconds )[ 0 ]; // Saves hours to var
   var minutes = convertToHHMMSS( seconds )[ 1 ]; // Saves minutes to var
   seconds = convertToHHMMSS( seconds )[ 2 ]; // Saves seconds to var
    
   // set text of timeText to current time in hh:mm:ss format
   timeText.text = hours + ":" + minutes + ":" + seconds;

   // set width of downloadProgress rectangle
   downloadProgress.width = movieMediaElement.downloadProgress *
      timeline.width;
   
   // if the movie has started playing, place the seek head at a
   // position representing the playback progress
   if ( movieMediaElement.naturalDuration )
   {
      seekHead[ "Canvas.Left" ] = ( ( movieMediaElement.position.Seconds /
         movieMediaElement.naturalDuration.Seconds ) * timeline.Width ) +
         timeline[ "Canvas.Left" ];
   } // end if
  
   else  // if not, place the seek head at the beginning
   {
      seekHead[ "Canvas.Left" ] = timeline[ "Canvas.Left" ];
   } // end else
      
   // if download is incomplete or movie is playing
   if ( movieMediaElement.downloadProgress != 1 ||  
      movieMediaElement.CurrentState == "Playing" )
   {
      timelineTimer.begin(); // run timelineTimer again
   } // end if
} // end function updateTime

// handle play and pause buttons
function playAndPauseButtonEventHandler( sender, eventArgs )
{
   // create variables to more easily access the Silverlight elements
   var movieMediaElement = sender.findName( "movieMediaElement" );
   var playButton = sender.findName( "playButton" );
   var pauseButton = sender.findName( "pauseButton" );
   var replayOverlay = sender.findName( "replayOverlay" );
   var timelineTimer = sender.findName( "timelineTimer" );

   // Check the CurrentState of the movie
   // pause if playing, play if paused or stopped
   if ( movieMediaElement.CurrentState == "Playing" )
   {
      movieMediaElement.pause();

      playButton.Visibility = "Visible"; // show play button
      pauseButton.Visibility = "Collapsed"; // hide pause button
   } // end if
   else if ( movieMediaElement.CurrentState == "Paused" ||
      movieMediaElement.CurrentState == "Stopped" )
   {
      movieMediaElement.play();

      timelineTimer.begin(); // start timelineTimer again

      pauseButton.Visibility = "Visible"; // show pause button
      playButton.Visibility = "Collapsed"; // hide play button

      replayOverlay.opacity = 0; // hide "Play Again?" button

      // remove the click handler from "Play Again?" button
      if ( replayOverlay.MouseLeftButtonDown )
      {
         replayOverlay.removeEventListener( "MouseLeftButtonDown",
            "replayMovie" );
      } // end if
   } // end if
} // end function playAndPauseButtonEventHandler

// handle stop button
function stopButtonEventHandler( sender, eventArgs )
{
   // create variables to more easily access the Silverlight elements
   var movieMediaElement = sender.findName( "movieMediaElement" );
   var playButton = sender.findName( "playButton" );
   var pauseButton = sender.findName( "pauseButton" );

   movieMediaElement.stop(); // stop the movie
   playButton.Visibility = "Visible"; // show play button
   pauseButton.Visibility = "Collapsed"; // hide pause button

   updateTime( sender );
} // end function stopButtonEventHandler

// handle MediaOpened event 
function movieOpenedHandler( sender, eventArgs )
{
   var replayOverlay = sender.findName( "replayOverlay" );
   var host = sender.getHost(); // allow access to host plug-in

   updateLayout( host.content.actualWidth, 
      host.content.actualHeight, sender );
   
   // hide "Play Again?" button
   replayOverlay.opacity = 0;

   // remove the click handler from "Play Again?" button
   if ( replayOverlay.MouseLeftButtonDown )
   {
      replayOverlay.removeEventListener( "MouseLeftButtonDown",
         "replayMovie" );
   } // end if
} // end function movieOpenedHandler

// handle when movie has reached end
function movieEndedHandler( sender, eventArgs )
{
   // create variables to more easily access the Silverlight elements
   var movieMediaElement = sender.findName( "movieMediaElement" );
   var playButton = sender.findName( "playButton" );
   var pauseButton = sender.findName( "pauseButton" );
   var replayOverlayFadeIn = sender.findName( "replayOverlayFadeIn" );
   var replayOverlay = sender.findName( "replayOverlay" );

   movieMediaElement.stop(); // stop the movie
   playButton.Visibility = "Visible"; // show play button
   pauseButton.Visibility = "Collapsed"; // hide pause button

   // show "Play Again?" button
   replayOverlayFadeIn.begin();
   replayOverlay.addEventListener( "MouseLeftButtonDown", "replayMovie" );

   updateTime( sender );
} // end function movieEndedHandler

// handle Crazy Dog button
function crazyDogHandler( sender, eventArgs )
{
   // create variables to more easily access the Silverlight elements
   var movieMediaElement = sender.findName( "movieMediaElement" );
   var playButton = sender.findName( "playButton" );
   var pauseButton = sender.findName( "pauseButton" );
   var baileyButton = sender.findName( "baileyButton" );
   var featherAndHammerButton = sender.findName( "featherAndHammerButton" );
   var apollo15LaunchButton = sender.findName( "apollo15LaunchButton" );
   var F35Button = sender.findName( "F35Button" );
   var timelineTimer = sender.findName( "timelineTimer" );

   movieMediaElement.stop(); // stop movie
   playButton.Visibility = "Visible"; // show play button
   pauseButton.Visibility = "Collapsed"; // hide pause button

   // set movie source
   movieMediaElement.source = "bailey.wmv";
   
   // set this thumbnail's text to red, set others back to white
   baileyButton.Foreground = "red";
   featherAndHammerButton.Foreground = "white";
   apollo15LaunchButton.Foreground = "white";
   F35Button.Foreground = "white";

   // begin timer to show download progress
   timelineTimer.begin();
} // end function crazyDogHandler

// handle Feather and Hammer button
function featherAndHammerHandler( sender, eventArgs )
{
   // create variables to more easily access the Silverlight elements
   var movieMediaElement = sender.findName( "movieMediaElement" );
   var playButton = sender.findName( "playButton" );
   var pauseButton = sender.findName( "pauseButton" );
   var baileyButton = sender.findName( "baileyButton" );
   var featherAndHammerButton = sender.findName( "featherAndHammerButton" );
   var apollo15LaunchButton = sender.findName( "apollo15LaunchButton" );
   var F35Button = sender.findName( "F35Button" );
   var timelineTimer = sender.findName( "timelineTimer" );
   
   movieMediaElement.stop(); // stop movie
   playButton.Visibility = "Visible"; // show play button
   pauseButton.Visibility = "Collapsed"; // hide pause button

   // set movie source
   movieMediaElement.source = "featherAndHammer.wmv";

   // set this thumbnail's text to red, set others back to white
   featherAndHammerButton.Foreground = "red";
   baileyButton.Foreground = "white";
   apollo15LaunchButton.Foreground = "white";
   F35Button.Foreground = "white";

   // begin timer to show download progress
   timelineTimer.begin();
} // end function featherAndHammerHandler

// handle Apollo 15 Launch button
function apollo15LaunchHandler( sender, eventArgs )
{
   // create variables to more easily access the Silverlight elements
   var movieMediaElement = sender.findName( "movieMediaElement" );
   var playButton = sender.findName( "playButton" );
   var pauseButton = sender.findName( "pauseButton" );
   var baileyButton = sender.findName( "baileyButton" );
   var featherAndHammerButton = sender.findName( "featherAndHammerButton" );
   var apollo15LaunchButton = sender.findName( "apollo15LaunchButton" );
   var F35Button = sender.findName( "F35Button" );
   var timelineTimer = sender.findName( "timelineTimer" );
   
   movieMediaElement.stop(); // stop movie
   playButton.Visibility = "Visible"; // show play button
   pauseButton.Visibility = "Collapsed"; // hide pause button

   // set movie source
   movieMediaElement.source = "apollo15Launch.wmv";

   // set this thumbnail's text to red, set others back to white
   apollo15LaunchButton.Foreground = "red";
   featherAndHammerButton.Foreground = "white";
   baileyButton.Foreground = "white";
   F35Button.Foreground = "white";

   // begin timer to show download progress
   timelineTimer.begin();
} // end function apollo15LaunchHandler

// handle F35 button
function F35Handler( sender, eventArgs )
{
   // create variables to more easily access the Silverlight elements
   var movieMediaElement = sender.findName( "movieMediaElement" );
   var playButton = sender.findName( "playButton" );
   var pauseButton = sender.findName( "pauseButton" );
   var baileyButton = sender.findName( "baileyButton" );
   var featherAndHammerButton = sender.findName( "featherAndHammerButton" );
   var apollo15LaunchButton = sender.findName( "apollo15LaunchButton" );
   var F35Button = sender.findName( "F35Button" );
   var timelineTimer = sender.findName( "timelineTimer" );
   
   movieMediaElement.stop(); // stop movie
   playButton.Visibility = "Visible"; // show play button
   pauseButton.Visibility = "Collapsed"; // hide pause button

   // set movie source
   movieMediaElement.source = "F35.wmv";

   // set this thumbnail's text to red, set others back to white
   F35Button.Foreground = "red";
   featherAndHammerButton.Foreground = "white";
   apollo15LaunchButton.Foreground = "white";
   baileyButton.Foreground = "white";

   // begin timer to show download progress
   timelineTimer.begin();
} // end function F35Handler

// handle toggle full screen button
function toggleFullScreen( sender, eventArgs )
{
   var host = sender.getHost(); // allow access to host plug-in
   
   // reverse current fullScreen state
   host.content.fullScreen = !host.content.fullScreen;
} // end function toggleFullScreen

// handle onFullScreenChange event
function onFullScreenChange( sender, eventArgs )
{
   // create variables to more easily access the Silverlight elements
   var playButton = sender.findName( "playButton" );
   var pauseButton = sender.findName( "pauseButton" );

   // update layout based on current dimensions
   updateLayout( host.content.actualWidth,
      host.content.actualHeight, sender );

   // update time and timeline
   updateTime( sender );

   // this is necessary for the buttons to be updated properly
   playButton[ "Canvas.Top" ] = 11;
   pauseButton[ "Canvas.Top" ] = 11;
   playButton[ "Canvas.Top" ] = 10;
   pauseButton[ "Canvas.Top" ] = 10;
} // end function onFullScreenChange

// reposition and resize elements based on new dimensions
function updateLayout( width, height, sender )
{
   // create variables to more easily access the Silverlight elements
   var movieMediaElement = sender.findName( "movieMediaElement" );
   var movieViewerCanvas = sender.findName( "movieViewerCanvas" );
   var timeline = sender.findName( "timeline" );
   var playButton = sender.findName( "playButton" );
   var pauseButton = sender.findName( "pauseButton" );
   var volumeCanvas = sender.findName( "volumeCanvas" );
   var controls = sender.findName( "controls" );
   var fullscreenButton = sender.findName( "fullscreenButton" );
   var timeCanvas = sender.findName( "timeCanvas" );
   var divider = sender.findName( "divider" );
   var titleText = sender.findName( "titleText" );
   var replayOverlay = sender.findName( "replayOverlay" );

   // resize and reposition the elements based on the screen dimensions
   movieViewerCanvas.Width = width;
   movieViewerCanvas.Height = height;
   movieMediaElement.Width = width;
   movieMediaElement.Height = height - 220;
   replayOverlay[ "Canvas.Left" ] = 
      ( width / 2 ) - ( ( replayOverlay.width ) / 2 );
   replayOverlay[ "Canvas.Top" ] = 
      ( ( height - 220 ) / 2 ) - ( replayOverlay.height / 2 );
   controls.width = width - 8;
   controls[ "Canvas.Left" ] = ( width / 2 ) - ( ( controls.width ) / 2 );
   controls[ "Canvas.Top" ] = height - 168;
   playButton[ "Canvas.Top" ] = 10;
   pauseButton[ "Canvas.Top" ] = 10;
   timeline.width = controls.width - 235;
   fullscreenButton[ "Canvas.Left" ] = controls.width - 135;
   timeCanvas[ "Canvas.Left" ] = controls.width - 100;
   volumeCanvas[ "Canvas.Left" ] = controls.width - 22;
   titleText[ "Canvas.Left" ] = ( width / 2 ) - ( ( titleText.width ) / 2 );
   divider.Width = width;
} // end function updateLayout

// handle timelineCanvas's MouseLeftButtonDown event
function timelineEventHandler( sender, eventArgs )
{
   // create variables to more easily access the Silverlight elements
   var movieMediaElement = sender.findName( "movieMediaElement" );
   var timeline = sender.findName( "timeline" );

   // determine new time from mouse position
   var seconds = ( ( eventArgs.getPosition( timeline ).x ) / 
      timeline.Width ) * movieMediaElement.NaturalDuration.seconds;
   var hours = convertToHHMMSS( seconds )[ 0 ]; // Saves hours to var
   var minutes = convertToHHMMSS( seconds )[ 1 ]; // Saves minutes to var
   seconds = convertToHHMMSS( seconds )[ 2 ]; // Saves seconds to var
   movieMediaElement.Position = hours + ":" + minutes + ":" + seconds;
   updateTime( sender );
} // end function timelineEventHandler

// handle volume's MouseLeftButtonDown event
function volumeHandler( sender, eventArgs )
{
   // create variables to more easily access the Silverlight elements
   var movieMediaElement = sender.findName( "movieMediaElement" );
   var volumeCanvas = sender.findName( "volumeCanvas" );
   var volumeHead = sender.findName( "volumeHead" );
   
   movieMediaElement.volume = 1 - ( ( eventArgs.getPosition( 
      volumeCanvas ).y ) / 30 );
   volumeHead[ "Canvas.Top" ] = eventArgs.getPosition( volumeCanvas ).
      y - 10;
} // end function volumeHandler

// handle click of "Play Again?" button
function replayMovie( sender, eventArgs )
{
   // create variables to more easily access the Silverlight elements
   var movieMediaElement = sender.findName( "movieMediaElement" );
   var replayOverlayFadeOut = sender.findName( "replayOverlayFadeOut" );
   var timelineTimer = sender.findName( "timelineTimer" );
   var replayOverlay = sender.findName( "replayOverlay" );
   
   // play movie, show pause button
   movieMediaElement.play();
   pauseButton.Visibility = "Visible";
   playButton.Visibility = "Collapsed";

   // start timelineTimer again
   timelineTimer.begin();

   // fade out "Play Again?" button
   replayOverlayFadeOut.begin();

   // remove the click handler from "Play Again?" button
   if ( replayOverlay.MouseLeftButtonDown )
   {
      replayOverlay.removeEventListener( 
         "MouseLeftButtonDown", "replayMovie" );
   } // end if
} // end function replayMovie

   // get the hours, minutes and seconds of the video's current position
   // Date element converts seconds to hh:mm:ss format
function convertToHHMMSS( seconds )
{
   var datetime = new Date( 0, 0, 0, 0, 0, seconds );
   var hours = datetime.getHours(); // Saves hours to var
   var minutes = datetime.getMinutes(); // Saves minutes to var
   var seconds = datetime.getSeconds(); // Saves seconds to var

   // ensure hh:mm:ss format
   if ( seconds < 10 )
   {
       seconds = "0" + seconds;
   } // end if

   if ( minutes < 10 ) 
   {
       minutes = "0" + minutes;
   } // end if

   if ( hours < 10 )
   {
      hours = "0" + hours;
   } // end if

   return [hours, minutes, seconds]
}